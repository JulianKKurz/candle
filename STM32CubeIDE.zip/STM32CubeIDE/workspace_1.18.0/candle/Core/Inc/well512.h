/*
 * well512.h
 *
 *  Created on: May 11, 2025
 *      Author: z004v3vh
 */

#ifndef INC_WELL512_H_
#define INC_WELL512_H_

#include <stdint.h>

// Initialisiert den WELL512-Zustand mit benutzerdefiniertem Seed
void well512_seed(uint32_t seed_array[16]);

// Initialisiert den WELL512-Zustand automatisch über ADC-Rauschen
void well512_seed_from_adc(void);

// Gibt eine neue 32-Bit-Zufallszahl zurück
uint32_t well512_rand(void);

#endif /* INC_WELL512_H_ */
