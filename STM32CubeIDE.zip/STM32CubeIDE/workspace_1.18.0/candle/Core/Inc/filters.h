/*
 * filters.h
 *
 *  Created on: Jan 26, 2025
 *      Author: z004v3vh
 */

#ifndef INC_FILTERS_H_
#define INC_FILTERS_H_

#define ALPHA_IIR    0.99f       /* Glättung des Signals                 */

// Struktur für IIR-Filter
typedef struct {
	float alpha;
	float prevVal;
} IIRFilterConfig;

float iir_filter_sample(IIRFilterConfig *cfg, float x);

#endif /* INC_FILTERS_H_ */
