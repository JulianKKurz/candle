/*
 * channels.h
 *
 *  Created on: May 25, 2025
 *      Author: z004v3vh
 */

#ifndef INC_CHANNELS_H_
#define INC_CHANNELS_H_

#include "stm32f1xx_hal.h"
#include <stdint.h>

/* Externer Timer-Handle (definiert in main.c) */
extern TIM_HandleTypeDef htim2;

/* Status Codes */
typedef enum {
    STATUS_OK = 0,
    STATUS_VALUE_TOO_HIGH,
    STATUS_VALUE_TOO_LOW,
    STATUS_UNKNOWN_ERROR
} status_t;

/* Verfügbare Kanäle */
typedef enum {
    CH_1 = 0,
    CH_2,
    CH_3,
    CH_4,
    CH_COUNT
} channel_t;

/* ---------- Funktionsprototypen ---------- */

/**
 * @brief Initialisiert alle Kanäle mit Standardwerten und berechnet die LUT.
 */
void init_channels(void);

/**
 * @brief Setzt den maximal erlaubten Strom für einen Kanal.
 *
 * @param channel Kanal (CH_1…CH_4).
 * @param current_A Maximalstrom in Ampere.
 * @return status_t Status der Operation.
 */
status_t set_max_current_A(channel_t channel, float current_A);

/**
 * @brief Gibt den konfigurierten Maximalstrom für einen Kanal zurück.
 *
 * @param channel Kanal.
 * @return float Maximalstrom in Ampere.
 */
float get_max_current_A(channel_t channel);

/**
 * @brief Setzt den gewünschten Strom eines Kanals (Ampere).
 *        Wandelt Strom über LED-Kennlinie in Duty-Cycle und bereitet Sigma-Delta vor.
 *
 * @param channel Kanal (CH_1…CH_4).
 * @param current_A Zielstrom in Ampere.
 * @return status_t Status der Operation.
 */
status_t set_channel_A(channel_t channel, float current_A);

/**
 * @brief Sigma-Delta-Dithering im Timer-Update-Interrupt (CCR-Update).
 *
 * Diese Funktion wird typischerweise von HAL_TIM_PeriodElapsedCallback()
 * bei TIM2-Interrupts aufgerufen.
 *
 * @param htim Pointer auf TIM-Handle (TIM2).
 */
void channel_period_elapsed_callback(TIM_HandleTypeDef *htim);

#endif /* INC_CHANNELS_H_ */
