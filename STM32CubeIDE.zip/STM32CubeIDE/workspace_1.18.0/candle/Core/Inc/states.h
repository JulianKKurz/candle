/*
 * states.h
 *
 *  Created on: May 13, 2025
 *      Author: z004v3vh
 */

#ifndef INC_STATES_H_
#define INC_STATES_H_

// ======= ENUMS =======
// Aufzählung der Zustände der Zustandsmaschine
typedef enum {
    STATE_INIT,
    STATE_ACTIVE,
    STATE_SLEEPING,
    STATE_ON,
    STATE_OFF
} AppState;

// ======= STATE =======

// Initialisiert den Systemzustand
void system_state_init(void);

// Zugriff auf aktuellen Zustand (lesen)
AppState system_state_get(void);

void system_state_set(AppState state);

// ======= BRIGHTNESS =======
void brightness_init(void);
int brightness_get(void);
void brightness_set(int value);
void increase_brightness(void);
void decrease_brightness(void);

// ======= SPEED =======
void speed_init(void);
int speed_get(void);
void speed_set(int value);
void increase_speed(void);
void decrease_speed(void);

// ======= CONSTANTS =======
#define BRIGHTNESS_MIN 0
#define BRIGHTNESS_MAX 100
#define SPEED_MIN 0
#define SPEED_MAX 200

#endif /* INC_STATES_H_ */
