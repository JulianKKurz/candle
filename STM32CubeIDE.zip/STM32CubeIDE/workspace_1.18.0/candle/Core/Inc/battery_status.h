/*
 * battery_status.h
 *
 *  Created on: Jan 22, 2025
 *      Author: z004v3vh
 */

#ifndef INC_BATTERY_STATUS_H_
#define INC_BATTERY_STATUS_H_

#include "voltage_monitoring.h"  // Adjust this include based on your STM32 series

// Threshold values for battery voltage (in millivolts)
#define BATT_HIGH_THRESHOLD   2222
#define BATT_LOW_THRESHOLD    1111

#endif /* INC_BATTERY_STATUS_H_ */
