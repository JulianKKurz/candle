/*
 * light_programs.h
 *  Created on: May 12 2025
 */

#ifndef INC_LIGHT_PROGRAMS_H_
#define INC_LIGHT_PROGRAMS_H_

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>
#include "pwm.h"

/* -------- Strukturen, die DEIN Programm bereits verwendet -------- */

/* 4‑Kanal‑Datenblock (RGBW / RGBA / whatever) */
typedef struct {
	const uint8_t *ch[N_CHANNELS]; /* Zeiger auf je 750‑Byte‑Arrays */
} LightChannels;

/* Vollständiges Lichtprogramm  */
typedef struct {
	const char *name; /* z. B. "candle"                 */
	int length; /* Anzahl Frames                  */
	int fps; /* Wiedergabe‑Rate                */
	int min_value; /* Helligkeitsbereich min         */
	int max_value; /* Helligkeitsbereich max         */
	int fade_frames;
	const LightChannels *data; /* Zeiger auf Kanaldaten          */
} LightProgram;

/* -------- Globale Verwaltungsgrößen -------- */
extern int current_program_index;
extern const LightProgram *current_program;
extern const LightProgram *const all_programs[];
extern const int num_programs;

/* -------- API -------- */
void init_program(void); /* erstes Programm wählen  */
void toggle_mode(void); /* nächstes Programm       */
const LightProgram* get_program(int index);

#ifdef __cplusplus
}
#endif

#endif /* INC_LIGHT_PROGRAMS_H_ */
