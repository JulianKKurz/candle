/*
 * current_measurement.h
 *
 *  Created on: Jul 18, 2025
 *      Author: z004v3vh
 */

#ifndef INC_CURRENT_MEASUREMENT_H_
#define INC_CURRENT_MEASUREMENT_H_

#include "channels.h"

#define INA_GAIN         50.0f     /* Verstärkung des INA (50 ×, 100 × … ) */
#define SHUNT_RESISTOR   0.075f    /* Shunt-Widerstand [Ω]                */

/**
 * @brief Aktiviert die Strommess-Hardware (Versorgung an).
 */
void i_sens_activate(void);

/**
 * @brief Deaktiviert die Strommess-Hardware und alle Schalter.
 */
void i_sens_deactivate(void);

/**
 * @brief Schaltet intern auf den gewünschten Messkanal um.
 *
 * @param channel Der auszuwählende Kanal (CH_1 bis CH_4).
 */
void i_sens_switch_channel(channel_t channel);

float i_sens_get_current_A(channel_t channel);

/** kalibriert echten Strom (A) aus Rohstrom (A) via current_lut[] */
float calibrate_current_A(float measured_A);

#endif /* INC_CURRENT_MEASUREMENT_H_ */
