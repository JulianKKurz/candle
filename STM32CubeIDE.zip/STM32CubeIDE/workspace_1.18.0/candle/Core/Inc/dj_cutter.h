#ifndef DJ_CUTTER_H
#define DJ_CUTTER_H

#include <stdint.h>
#include "light_programs.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * Füllt einen bereits allozierten Puffer (dest[ch][len])
 * mit einer neuen, zufällig zusammengeschnittenen Sequenz,
 * basierend auf den Daten aus @p program.
 *
 *  - dest           Pivot-/Cutter-Zielpuffer (N_CHANNELS × len Bytes)
 *  - program        aktuelles Light-Program (liefert Source-Material)
 *
 * Die Länge ergibt sich aus  program->length  und
 * die Crossfade-Länge aus   program->fade_frames.
 */
void dj_cutter_generate_all_channels(uint8_t **dest,
                                     const LightProgram *program);

#ifdef __cplusplus
}
#endif
#endif /* DJ_CUTTER_H */
