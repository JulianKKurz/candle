/* pwm.h ----------------------------------------------------------------
 * Low-Level-Treiber für die 4-Kanal-PWM-Ausgabe inkl. DJ-Cutter-Handling
 * -------------------------------------------------------------------- */
#ifndef PWM_H
#define PWM_H

#include "stm32f1xx_hal.h"
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/* -------- Konstanten ------------------------------------------------- */
#define N_CHANNELS   4          /* R, G, B, W bzw. 4 Flammen            */
#define SINK_FPS     1000       /* Der TIM3-ISR läuft mit 1 kHz         */

/* -------- Öffentliche API ------------------------------------------- */
void candle_init(void);                                       /* Puffer + Timer */
void candle_free(void);                                       /* Speicher räumen */
void candle_run(void);                                        /* PWM an          */
void candle_stop(void);                                       /* PWM aus         */
void candle_period_elapsed_callback(TIM_HandleTypeDef *htim); /* 1 kHz-ISR       */

#ifdef __cplusplus
}
#endif
#endif /* PWM_H */
