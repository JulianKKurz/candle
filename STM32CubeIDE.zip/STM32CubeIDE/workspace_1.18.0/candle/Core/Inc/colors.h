/*
 * colors.h
 *
 *  Created on: Jan 22, 2025
 *      Author: z004v3vh
 */

#ifndef INC_COLORS_H_
#define INC_COLORS_H_

// RGB-Farben als separate Funktion oder zusammen
/**
 * @brief Setzt die RGB-Farbe der LED.
 * @param r Wert für Rot (0-255)
 * @param g Wert für Grün (0-255)
 * @param b Wert für Blau (0-255)
 */

#include <stdint.h>             // Für uint8_t
void set_rgb_color(uint8_t r, uint8_t g, uint8_t b);

#endif /* INC_COLORS_H_ */
