/*
 * system_state.h
 *
 *  Created on: May 6, 2025
 *      Author: z004v3vh
 */

#ifndef SYSTEM_STATE_H
#define SYSTEM_STATE_H

#ifdef __cplusplus
extern "C" {
#endif

// Hauptloop des Zustandsautomaten
void system_state_loop(void);

#ifdef __cplusplus
}
#endif

#endif // SYSTEM_STATE_H
