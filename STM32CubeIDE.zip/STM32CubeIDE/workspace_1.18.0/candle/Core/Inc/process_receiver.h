#ifndef INC_PROCESS_RECEIVER_H_
#define INC_PROCESS_RECEIVER_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "main.h"

// Schwellenwerte in µs
#define TIMEOUT_THRESHOLD    8000
#define ONE_BIT_THRESHOLD    1700
#define ZERO_BIT_THRESHOLD   1000

#define CODE_BIT_LENGTH      32
#define RECEIVER_GPIO_PIN    GPIO_PIN_11

extern TIM_HandleTypeDef htim1;

// IR-Kommandos als Enum
typedef enum {
    IR_CMD_NONE = 0,
    IR_CMD_ON_OFF,
    IR_CMD_MODE,
    IR_CMD_BRIGHTNESS_UP,
    IR_CMD_BRIGHTNESS_DOWN,
    IR_CMD_SPEED_SLOW,
    IR_CMD_SPEED_RAPIDE
} IR_Command;

// Empfangszustand
typedef enum {
    RX_IDLE,
    RX_RECEIVING,
	RX_DEBOUNCE,
    RX_DONE
} ReceiverState;

// Öffentliche API
void ProcessReceiver_EXTI_Callback(void);
IR_Command decode_ir_code(uint32_t code);

ReceiverState get_rx_state(void);
void set_rx_state(ReceiverState state);
uint32_t get_last_code(void);
void set_last_code(uint32_t code);
void reset_receiver(void);

#ifdef __cplusplus
}
#endif

#endif /* INC_PROCESS_RECEIVER_H_ */
