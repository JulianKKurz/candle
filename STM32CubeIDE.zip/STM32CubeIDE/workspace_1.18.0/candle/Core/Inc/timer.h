/*
 * timer.h
 *
 *  Created on: Jan 25, 2025
 *      Author: z004v3vh
 */

#ifndef INC_TIMER_H_
#define INC_TIMER_H_

#include <stdint.h>
#include <stddef.h>
#include "stm32f1xx_hal.h"

// Falls Sie C++ verwenden, sorgt dies für die richtige Linkage
#ifdef __cplusplus
extern "C" {
#endif

// Maximale Anzahl von Software-Timern
#define MAX_TIMERS 10

/**
 * @brief Struktur, die einen Software-Timer repräsentiert.
 */
typedef struct {
    uint32_t start_time;    // Startzeit des Timers in Millisekunden
    uint32_t duration;      // Dauer des Timers in Millisekunden
    volatile uint8_t flag;  // Flag, das anzeigt, ob der Timer abgelaufen ist
    uint8_t active;         // Flag, das anzeigt, ob der Timer aktiv ist
} Timer;

void timer_delay_ms(uint32_t ms);

/**
 * @brief Initialisiert das Timer-Modul und setzt alle Timer zurück.
 */
void timer_init(void);

/**
 * @brief Erstellt und startet einen neuen Software-Timer.
 *
 * @param duration_ms Dauer des Timers in Millisekunden.
 * @return Pointer auf den erstellten Timer, oder NULL, wenn kein Timer verfügbar ist.
 */
Timer* timer_create(uint32_t duration_ms);

/**
 * @brief Überprüft, ob ein bestimmter Timer abgelaufen ist.
 *
 * @param timer Pointer auf den zu überprüfenden Timer.
 * @return uint8_t 1, wenn der Timer abgelaufen ist, sonst 0.
 */
uint8_t timer_is_expired(Timer* timer);

/**
 * @brief Setzt das abgelaufene Flag eines Timers zurück.
 *
 * @param timer Pointer auf den Timer.
 */
void timer_reset_flag(Timer* timer);

/**
 * @brief Löscht einen Timer und macht ihn verfügbar für neue Timer.
 *
 * @param timer Pointer auf den zu löschenden Timer.
 */
void timer_delete(Timer* timer);

/**
 * @brief Gibt die verstrichene Zeit in Millisekunden zurück.
 *
 * @return uint32_t Verstrichene Millisekunden.
 */
uint32_t timer_get_time(void);

/**
 * @brief Inkrementiert die Millisekunden um 1.
 */
void timer_increment(void);

/**
 * @brief Callback-Funktion, die aufgerufen wird, wenn der Timer eine Periode abläuft.
 *
 * @param htim Zeiger auf die Timer-Handle-Struktur.
 */
void timer_period_elapsed_callback(TIM_HandleTypeDef* htim);

#ifdef __cplusplus
}
#endif

#endif /* INC_TIMER_H_ */
