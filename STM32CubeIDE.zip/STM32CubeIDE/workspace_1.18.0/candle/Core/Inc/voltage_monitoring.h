#ifndef INC_VOLTAGE_MONITORING_H_
#define INC_VOLTAGE_MONITORING_H_

#include <stdbool.h>

// --- Konstanten ---
#define ADC_MAX                         4095.0f
#define VREF                            3.3f

#define TEMP_M                          -0.257f
#define TEMP_B                          454.62f

#define TEMP_ADC_INDEX                  0
#define BATTERY_ADC_INDEX               1
#define USB_ADC_INDEX                   2
#define ISENS_ADC_INDEX                 3  // Strommessung

#define FILTER_SIZE                     8
#define ADC_NUM_CHANNELS                4  // <- Anzahl aller genutzten ADC-Kanäle

bool voltage_monitoring_init(void);
bool voltage_monitoring_is_initialized(void);
void voltage_monitoring_update(void);

float get_voltage_battery_V(void);
float get_smoothed_battery_voltage_V(void);
float get_voltage_isens_V(void);     // ersetzt charger
float get_voltage_usb_V(void);
float get_temperature_mpu_C(void);

#endif /* INC_VOLTAGE_MONITORING_H_ */
