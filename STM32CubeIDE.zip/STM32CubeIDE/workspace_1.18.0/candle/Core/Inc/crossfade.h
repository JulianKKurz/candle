/*
 * crossfade.h
 *
 *  Created on: May 23, 2025
 *      Author: z004v3vh
 */

#ifndef INC_CROSSFADE_H_
#define INC_CROSSFADE_H_

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>

/**
 * Auswahl des Interpolationsmodus.
 */
typedef enum {
    COSINE,  /**< Cosinus-förmiger Verlauf (weich) */
    LINEAR   /**< Linearer Verlauf (direkt) */
} CrossfadeMode;

/**
 * Crossfade zwischen zwei Werten mit wählbarem Interpolationsmodus.
 *
 * @param pos     Position innerhalb des Übergangsbereichs (0 ... length)
 * @param vOut    Wert des alten Abschnitts
 * @param vIn     Wert des neuen Abschnitts
 * @param length  Gesamtlänge des Übergangs
 * @param mode    Interpolationsmodus (Cosine oder Linear)
 * @return        Interpolierter Wert
 */
float crossfade(int pos, float vOut, float vIn, int length, CrossfadeMode mode);

#ifdef __cplusplus
}
#endif

#endif /* INC_CROSSFADE_H_ */
