/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f1xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

void HAL_TIM_MspPostInit(TIM_HandleTypeDef *htim);

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define BATTERY_VCC_Pin GPIO_PIN_5
#define BATTERY_VCC_GPIO_Port GPIOA
#define I_SENS_OUT_Pin GPIO_PIN_6
#define I_SENS_OUT_GPIO_Port GPIOA
#define USB_5V_Pin GPIO_PIN_0
#define USB_5V_GPIO_Port GPIOB
#define I_SENS_VCC_Pin GPIO_PIN_10
#define I_SENS_VCC_GPIO_Port GPIOB
#define IR_SENSOR_Pin GPIO_PIN_11
#define IR_SENSOR_GPIO_Port GPIOB
#define IR_SENSOR_EXTI_IRQn EXTI15_10_IRQn
#define SENSOR_VCC_Pin GPIO_PIN_12
#define SENSOR_VCC_GPIO_Port GPIOB
#define SWITCH_2_Pin GPIO_PIN_14
#define SWITCH_2_GPIO_Port GPIOB
#define IR_TX_Pin GPIO_PIN_8
#define IR_TX_GPIO_Port GPIOA
#define BLUE_Pin GPIO_PIN_9
#define BLUE_GPIO_Port GPIOA
#define GREEN_Pin GPIO_PIN_10
#define GREEN_GPIO_Port GPIOA
#define RED_Pin GPIO_PIN_11
#define RED_GPIO_Port GPIOA
#define STATUS_Pin GPIO_PIN_4
#define STATUS_GPIO_Port GPIOB
#define SWITCH_1_Pin GPIO_PIN_5
#define SWITCH_1_GPIO_Port GPIOB
#define SWITCH_3_Pin GPIO_PIN_8
#define SWITCH_3_GPIO_Port GPIOB
#define HOLD_Pin GPIO_PIN_9
#define HOLD_GPIO_Port GPIOB

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
