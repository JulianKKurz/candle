/*
 * mapping.h
 *
 *  Created on: May 6, 2025
 *      Author: z004v3vh
 */

#ifndef MAPPING_H_
#define MAPPING_H_

#include <stdint.h>

// Mapping-Konstanten
#define MAP_OUT_MIN   0
#define MAP_OUT_MAX   255

// Mapping-Funktion: float → uint16_t
uint16_t map_value(float v, float map_in_min, float map_in_max);

float stretch(float value, float center, float signal_min, float signal_max, float desired_gain);

#endif // MAPPING_H_
