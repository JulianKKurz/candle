/*
 * crossfade.c
 *
 *  Created on: May 23, 2025
 *      Author: z004v3vh
 */

#include "crossfade.h"
#include <math.h>

float crossfade(int pos, float vOut, float vIn, int length, CrossfadeMode mode)
{
    if (pos < 0 || pos > length || length <= 0)
        return 0.0f;  // Fehlerfall

    float alpha;

    switch (mode) {
        case COSINE:
            alpha = 0.5f * (1.0f - cosf((float)M_PI * pos / (float)length));
            break;

        case LINEAR:
            alpha = (float)pos / (float)length;
            break;

        default:
            return 0.0f;
    }

    return (1.0f - alpha) * vOut + alpha * vIn;
}
