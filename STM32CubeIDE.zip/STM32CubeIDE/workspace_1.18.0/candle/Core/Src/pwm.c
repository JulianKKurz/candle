/* pwm.c ----------------------------------------------------------------
 * 4-Kanal-PWM-Ausgabe mit Zufalls-Clip-Cutter, IIR-Filter und Mapping
 * -------------------------------------------------------------------- */
#include "pwm.h"
#include "dj_cutter.h"           /* neuer Algorithmus */
#include "filters.h"
#include "mapping.h"
#include "light_programs.h"
#include "voltage_monitoring.h"
#include "well512.h"
#include "states.h"
#include "crossfade.h"
#include "channels.h"

#include <math.h>                /* floorf()          */
#include <string.h>              /* memset()          */
#include <stdlib.h>              /* malloc(), free()  */

/* ---------- externe HW-Handles (kommen aus main.c o. ä.) ------------- */
extern TIM_HandleTypeDef htim2; /* PWM-Timer (4 Kanäle) */
extern TIM_HandleTypeDef htim3; /* 1 kHz-Interrupt-Timer */

/* ---------- Laufzeit-Daten ------------------------------------------ */
static volatile uint8_t candle_active = 0;

static uint8_t **cutter_data = NULL; /* dynamischer Puffer      */
static IIRFilterConfig iirConfigs[N_CHANNELS]; /* Tiefpass je Kanal       */

static float phase = 0.0f; /* Fractional-Abspielposition           */
static float phaseInc = 0.0f; /* += fps / SINK_FPS                    */
static uint8_t loopOnce = 0; /* Flag: schon einmal durchgelaufen?    */

/* ---------- Convenience-Makros -------------------------------------- */
#define CUR_LEN  (current_program->length)
#define PWM_MAX  (TIM2->ARR)    /* ARR bestimmt die 12-Bit-PWM-Aufl.    */

/* =====================================================================
 *                       Steuer-Funktionen
 * ===================================================================*/
void candle_run(void) {
	candle_active = 1;
}
void candle_stop(void) {
	candle_active = 0;
}

/* =====================================================================
 *                       Initialisierung
 * ===================================================================*/
void candle_init(void) {
	candle_stop();

	/* ----- 0) alten Puffer freigeben -------------------------------- */
	if (cutter_data) {
		for (int ch = 0; ch < N_CHANNELS; ++ch)
			free(cutter_data[ch]);
		free(cutter_data);
		cutter_data = NULL;
	}

	/* ----- 1) neuen Puffer allozieren ------------------------------- */
	int len = current_program->length;
	cutter_data = malloc(N_CHANNELS * sizeof(uint8_t*));
	for (int ch = 0; ch < N_CHANNELS; ++ch) {
		cutter_data[ch] = malloc(len);
		if (!cutter_data[ch]) /* Out-of-RAM-Fail-Safe */
			while (1)
				;
	}

	/* ----- 2) PWM-Timer starten ------------------------------------- */
	__HAL_TIM_SET_COUNTER(&htim2, 0);
	HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_1);
	HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_2);
	HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_3);
	HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_4);

	/* ----- 3) RNG-Seed ---------------------------------------------- */
	well512_seed_from_adc();

	/* ----- 4) IIR-Filter zurücksetzen ------------------------------- */
	for (int ch = 0; ch < N_CHANNELS; ++ch)
		iirConfigs[ch] =
				(IIRFilterConfig ) { .alpha = ALPHA_IIR, .prevVal = 0 };

	/* ----- 5) Cutter-Sequenz erzeugen ------------------------------- */
	dj_cutter_generate_all_channels(cutter_data, current_program);

	/* ----- 6) Phasensteuerung --------------------------------------- */
	phase = 0.0f;
	loopOnce = 0;
	phaseInc = (float) (current_program->fps) / (float) SINK_FPS;

	candle_run();
}

/* =====================================================================
 *                       Speicher freigeben (optional)
 * ===================================================================*/
void candle_free(void) {
	if (!cutter_data)
		return;

	for (int ch = 0; ch < N_CHANNELS; ++ch)
		free(cutter_data[ch]);
	free(cutter_data);
	cutter_data = NULL;
}

/* =====================================================================
 *                       1 kHz-Interrupt-Handler
 * ===================================================================*/
void candle_period_elapsed_callback(TIM_HandleTypeDef *htim) {
	// Beende frühzeitig, falls ADC/DMA nicht initialisiert wurde
	if (!voltage_monitoring_is_initialized()) {
		return;
	}

	// Nur auf Timer 3 reagieren
	if (htim->Instance != TIM3)
		return;

	// Prüfen, ob die Animation überhaupt aktiv ist und die Daten vorhanden sind
	if (!candle_active || !cutter_data || !current_program)
		return;

	/* ----- Cutter-Phase fortschreiten -------------------------------
	 * Die aktuelle Position innerhalb der Cutter-Kurven wird schrittweise erhöht.
	 * Dadurch läuft die Animation kontinuierlich weiter.
	 */
	phase += phaseInc * ((float)speed_get()/100);

	/* ----- Prüfen, ob das Ende der Kurve erreicht wurde -------------
	 * Wenn das Ende der animierten Sequenz erreicht wurde:
	 * - einmaliges Setzen von loopOnce zur Unterscheidung beim 1. Durchlauf
	 * - neue Zufallswerte für alle Kanäle generieren
	 * - sanften Übergang vorbereiten durch Setzen in den Fade-Bereich
	 */
	if (phase >= (float)(CUR_LEN - 1)) {
		if (!loopOnce)
			loopOnce = 1;

		dj_cutter_generate_all_channels(cutter_data, current_program);
		phase = (float) current_program->fade_frames;
	}

	/* ----- Interpolationsindex vorbereiten --------------------------
	 * Für die Übergänge zwischen zwei Werten wird linear interpoliert.
	 * Dazu wird:
	 * - der Integer-Index `idx` (linker Punkt) berechnet
	 * - `frac` = Bruchteil dazwischen für weichen Übergang
	 * Achtung: Clamping, um Array-Überlauf zu vermeiden!
	 */
	int idx = (int) floorf(phase);
	float frac = phase - (float) idx;
	if (idx >= CUR_LEN - 1)
		idx = CUR_LEN - 2;

	/* ----- Interpolation je Kanal -----------------------------------
	 * Für jeden Kanal wird ein interpolierter Rohwert zwischen zwei Samples berechnet.
	 * Die Interpolation erfolgt mit definierter Kurvenform (hier LINEAR).
	 */
	float raw[N_CHANNELS];
	for (int ch = 0; ch < N_CHANNELS; ++ch) {
		float v0 = cutter_data[ch][idx];
		float v1 = cutter_data[ch][idx + 1];
		raw[ch] = crossfade((int)(frac * 1000), v0, v1, 1000, LINEAR);
	}

	/* ----- Filtern und physikalische Umsetzung ----------------------
	 * Der interpolierte Rohwert wird:
	 * - durch einen IIR-Filter geglättet
	 * - mit der globalen Helligkeit skaliert (0–1)
	 * - in eine reale Spannung umgerechnet (je nach maximal erlaubtem Strom)
	 * - per PWM auf den Kanal ausgegeben
	 */
	float brightness_factor_1 = brightness_get() / 100.0f;

	for (int ch = 0; ch < CH_COUNT; ++ch) {
		// Glätten des Rohsignals für diesen Kanal

		float mapped = map_value(raw[ch], current_program->min_value, current_program->max_value);

		// Normierung auf 0.0–1.0 (Helligkeit + 8bit Skalierung)
		float brightness_1 = brightness_factor_1 * mapped / 0xff;

		// Umwandlung des normierten Steuerwerts (Helligkeit) in eine reale physikalische Größe (Strom in Ampere),
		// basierend auf dem maximal zulässigen Strom des jeweiligen Kanals.
		float current = get_max_current_A(ch) * brightness_1;

		float filtered = iir_filter_sample(&iirConfigs[ch], current);

		// PWM setzen entsprechend berechneter Spannung
		set_channel_A(ch, filtered);

	}
}
