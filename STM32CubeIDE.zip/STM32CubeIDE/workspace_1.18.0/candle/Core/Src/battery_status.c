/*
 * battery_status.c
 *
 *  Created on: Jan 22, 2025
 *      Author: z004v3vh
 */
