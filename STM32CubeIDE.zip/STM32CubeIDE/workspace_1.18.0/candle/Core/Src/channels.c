#include "voltage_monitoring.h"
#include "main.h"
#include "channels.h"
#include "stm32f1xx_hal.h"
#include <math.h>
#include <stdint.h>

/* ---------- Konstanten -------------------------------------------------- */
#define LUT_SIZE          2048u          /* Gesamtpunkte                    */
#define LUT_HALF          (LUT_SIZE/2u)  /* 1024 Punkte pro Teilbereich     */

#define SD_RESOLUTION     0xffff         /* 16-Bit Sigma-Delta              */

#define CURRENT_LOW_MAX_A 0.010f         /* 10  mA Grenze                   */
#define CURRENT_MAX_A     0.120f         /* 120 mA Gesamtende               */

static const float a_fit = 0.0003173f;
static const float b_fit = 0.8543f;

/* ---------- Globale Daten ---------------------------------------------- */
extern TIM_HandleTypeDef htim2;

static float duty_lut[LUT_SIZE]          = {0.0f};
static float max_current_A[CH_COUNT]     = {0};

static uint32_t acc [CH_COUNT] = {0};
static uint16_t base[CH_COUNT] = {0};
static uint32_t frac[CH_COUNT] = {0};

/* ---------- LUT vorberechnen (2 Segmente) ------------------------------ */
static void build_lut(void)
{
    /* Segment 0 … 10 mA -------------------------------------------------- */
    for (uint32_t i = 0; i < LUT_HALF; ++i) {
        float current = ((float)i) * CURRENT_LOW_MAX_A / (LUT_HALF - 1u);
        float duty_f  = powf(current / a_fit, 1.0f / b_fit);

        if (duty_f > (float)htim2.Init.Period)
            duty_f = (float)htim2.Init.Period;

        duty_lut[i] = duty_f;
    }

    /* Segment 10 … 120 mA ----------------------------------------------- */
    for (uint32_t i = LUT_HALF; i < LUT_SIZE; ++i) {
        float current = CURRENT_LOW_MAX_A +
            ((float)(i - LUT_HALF)) *
            (CURRENT_MAX_A - CURRENT_LOW_MAX_A) /
            (float)(LUT_SIZE - LUT_HALF - 1u);

        float duty_f = powf(current / a_fit, 1.0f / b_fit);
        if (duty_f > (float)htim2.Init.Period)
            duty_f = (float)htim2.Init.Period;

        duty_lut[i] = duty_f;
    }
}

/* ---------- Initialisierung -------------------------------------------- */
void init_channels(void)
{
    set_max_current_A(CH_1, 0.12f);
    set_max_current_A(CH_2, 0.12f);
    set_max_current_A(CH_3, 0.03f);
    set_max_current_A(CH_4, 0.12f);

    build_lut();
}

/* ---------- Max-Current Setter / Getter -------------------------------- */
status_t set_max_current_A(channel_t ch, float current_A)
{
    if (ch >= CH_COUNT)       return STATUS_UNKNOWN_ERROR;
    if (current_A < 0.0f)     return STATUS_VALUE_TOO_LOW;
    if (current_A > 100.0f)   return STATUS_VALUE_TOO_HIGH;

    max_current_A[ch] = current_A;
    return STATUS_OK;
}
float get_max_current_A(channel_t ch)
{
    return (ch < CH_COUNT) ? max_current_A[ch] : 0.0f;
}

/* ---------- LUT-Zugriff ohne Interpolation ----------------------------- */
static inline float duty_from_current(float current_A)
{
    if (current_A <= 0.0f) return 0.0f;
    if (current_A >= CURRENT_MAX_A) return duty_lut[LUT_SIZE-1u];

    uint32_t idx;

    if (current_A <= CURRENT_LOW_MAX_A) {
        /* Bereich 0–10 mA */
        idx = (uint32_t)(current_A * (LUT_HALF - 1u) / CURRENT_LOW_MAX_A + 0.5f);
    } else {
        /* Bereich 10–120 mA */
        idx = LUT_HALF + (uint32_t)(
              (current_A - CURRENT_LOW_MAX_A) *
              (LUT_SIZE - LUT_HALF - 1u) /
              (CURRENT_MAX_A - CURRENT_LOW_MAX_A) + 0.5f);
    }

    if (idx >= LUT_SIZE) idx = LUT_SIZE - 1u; /* Sicherheit */
    return duty_lut[idx];
}

/* ---------- PWM-Sollwert setzen ---------------------------------------- */
status_t set_channel_A(channel_t ch, float current_A)
{
    if (ch >= CH_COUNT)   return STATUS_UNKNOWN_ERROR;
    if (current_A < 0.0f) return STATUS_VALUE_TOO_LOW;

    if (current_A > max_current_A[ch])
        current_A = max_current_A[ch];

    float duty_f = duty_from_current(current_A);

    base[ch] = (uint16_t)duty_f;
    frac[ch] = (uint32_t)((duty_f - (float)base[ch]) * SD_RESOLUTION + 0.5f);

    return STATUS_OK;
}

/* ---------- CCR schreiben --------------------------------------------- */
static inline void set_ccr(uint8_t ch, uint16_t val)
{
    switch (ch) {
        case CH_1: TIM2->CCR1 = val; break;
        case CH_2: TIM2->CCR2 = val; break;
        case CH_3: TIM2->CCR4 = val; break;
        case CH_4: TIM2->CCR3 = val; break;
    }
}

void channel_period_elapsed_callback(TIM_HandleTypeDef *htim)
{
    if (htim->Instance != TIM2) return;

    for (uint8_t ch = 0; ch < CH_COUNT; ++ch) {

        // 1. Zielwert berechnen (z. B. duty = base + frac/SD_RES)
        uint32_t duty = base[ch] * SD_RESOLUTION + frac[ch];

        // 2. IIR-Filter: y[n] = y[n−1] + (x[n] − y[n−1]) >> 3;
        static uint32_t filt[CH_COUNT] = {0};  // high-res 16+ bits

        filt[ch] += (int32_t)(duty - filt[ch]) >> 10;

        // 3. Sigma-Delta: wie bisher, aber mit geglättetem Wert
        acc[ch] += filt[ch] & (SD_RESOLUTION - 1);
        if (acc[ch] >= SD_RESOLUTION) {
            acc[ch] -= SD_RESOLUTION;
            set_ccr(ch, (filt[ch] >> 16) + 1);
        } else {
            set_ccr(ch, filt[ch] >> 16);
        }
    }
}

