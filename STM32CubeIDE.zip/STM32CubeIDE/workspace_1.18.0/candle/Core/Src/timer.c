/*
 * timer.c
 *
 *  Created on: Jan 25, 2025
 *      Author: z004v3vh
 */

#include "timer.h"

// Globale Variable, um die Millisekunden zu speichern
static volatile uint32_t milliseconds = 0;

// Array zur Verwaltung der Software-Timer
static Timer timers[MAX_TIMERS];

/**
 * @brief Initialisiert das Timer-Modul und setzt alle Timer zurück.
 */
void timer_init(void) {
	// Setze alle Timer als inaktiv
	for (uint8_t i = 0; i < MAX_TIMERS; i++) {
		timers[i].active = 0;
		timers[i].flag = 0;
		timers[i].start_time = 0;
		timers[i].duration = 0;
	}
}

void timer_delay_ms(uint32_t ms) {
	Timer *t = timer_create(ms);
	if (!t)
		return; // optional: Fehlerhandling
	while (!timer_is_expired(t)) {
		__WFI();  // Stromsparmodus während Warten
	}
	timer_delete(t);
}

/**
 * @brief Erstellt und startet einen neuen Software-Timer.
 *
 * @param duration_ms Dauer des Timers in Millisekunden.
 * @return Pointer auf den erstellten Timer, oder NULL, wenn kein Timer verfügbar ist.
 */
Timer* timer_create(uint32_t duration_ms) {
	for (uint8_t i = 0; i < MAX_TIMERS; i++) {
		if (!timers[i].active) {
			timers[i].active = 1;
			timers[i].duration = duration_ms;
			timers[i].start_time = timer_get_time();
			timers[i].flag = 0;
			return &timers[i];
		}
	}
	// Kein verfügbarer Timer
	return NULL;
}

/**
 * @brief Überprüft, ob ein bestimmter Timer abgelaufen ist.
 *
 * @param timer Pointer auf den zu überprüfenden Timer.
 * @return uint8_t 1, wenn der Timer abgelaufen ist, sonst 0.
 */
uint8_t timer_is_expired(Timer *timer) {
	if (timer == NULL || !timer->active) {
		return 0;
	}

	if (!timer->flag) {
		uint32_t current_time = timer_get_time();
		// Überprüfe, ob die Dauer erreicht ist (unter Berücksichtigung von Überläufen)
		if ((current_time - timer->start_time) >= timer->duration) {
			timer->flag = 1;
			return 1;
		}
	}
	return timer->flag;
}

/**
 * @brief Setzt das abgelaufene Flag eines Timers zurück.
 *
 * @param timer Pointer auf den Timer.
 */
void timer_reset_flag(Timer *timer) {
	if (timer != NULL && timer->active) {
		timer->flag = 0; // Setzt das Flag zurück
		timer->start_time = timer_get_time(); // Startzeit neu setzen
	}
}

/**
 * @brief Löscht einen Timer und macht ihn verfügbar für neue Timer.
 *
 * @param timer Pointer auf den zu löschenden Timer.
 */
void timer_delete(Timer *timer) {
	if (timer != NULL && timer->active) {
		timer->active = 0;
		timer->flag = 0;
		timer->start_time = 0;
		timer->duration = 0;
	}
}

/**
 * @brief Gibt die aktuelle verstrichene Zeit in Millisekunden zurück.
 *
 * @return uint32_t Verstrichene Millisekunden.
 */
uint32_t timer_get_time(void) {
	return __atomic_load_n(&milliseconds, __ATOMIC_RELAXED); // Atomare Leseoperation
}

/**
 * @brief Inkrementiert die Millisekunden um 1.
 */
void timer_increment(void) {
	__atomic_fetch_add(&milliseconds, 1, __ATOMIC_RELAXED); // Atomare Schreiboperation
}

/**
 * @brief Callback-Funktion, die aufgerufen wird, wenn der Timer eine Periode abläuft.
 *
 * @param htim Zeiger auf die Timer-Handle-Struktur.
 */
void timer_period_elapsed_callback(TIM_HandleTypeDef *htim) {
	if (htim->Instance == TIM3) { // Überprüfen, ob es sich um den gewünschten Timer handelt
		// Millisekunden inkrementieren
		timer_increment();

		// Überprüfung aller aktiven Software-Timer
		for (uint8_t i = 0; i < MAX_TIMERS; i++) {
			if (timers[i].active && !timers[i].flag) {
				uint32_t current_time = timer_get_time();
				if ((current_time - timers[i].start_time)
						>= timers[i].duration) {
					timers[i].flag = 1; // Flag setzen, wenn Timer abgelaufen ist
				}
			}
		}
	}
}
