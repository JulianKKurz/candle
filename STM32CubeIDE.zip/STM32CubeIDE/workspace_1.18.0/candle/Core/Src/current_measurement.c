/*
 * current_measurement.c
 *
 *  Created on: Jul 18, 2025
 *      Author: z004v3vh
 */

#include "main.h"
#include "current_measurement.h"
#include "voltage_monitoring.h"

#include <stdlib.h>   // qsort
#include <string.h>   // memmove

// --- Konfiguration ---
#define NUM_VALUES 100

// --- Interner Messpuffer ---
static float current_buffer[NUM_VALUES] = {0.0f};
static int   buffer_count = 0;

// --- Hilfsfunktionen ---
static int compare_float(const void *a, const void *b)
{
    float fa = *(const float*)a;
    float fb = *(const float*)b;
    return (fa > fb) - (fa < fb);
}

static float median_of_buffer(const float *buf, int n)
{
    // Für Median sortieren wir eine Kopie
    float tmp[NUM_VALUES];
    memcpy(tmp, buf, (size_t)n * sizeof(float));
    qsort(tmp, (size_t)n, sizeof(float), compare_float);

    if ((n & 1) == 0) {
        // gerade Anzahl
        return 0.5f * (tmp[n/2 - 1] + tmp[n/2]);
    } else {
        // ungerade Anzahl
        return tmp[n/2];
    }
}

// --- Public API ---
void i_sens_activate(void)
{
    // Versorgung für Stromsensor aktivieren
    HAL_GPIO_WritePin(I_SENS_VCC_GPIO_Port, I_SENS_VCC_Pin, GPIO_PIN_SET);
}

void i_sens_deactivate(void)
{
    // Versorgung deaktivieren
    HAL_GPIO_WritePin(I_SENS_VCC_GPIO_Port, I_SENS_VCC_Pin, GPIO_PIN_RESET);

    // Alle Schaltpins auf LOW setzen
    HAL_GPIO_WritePin(SWITCH_1_GPIO_Port, SWITCH_1_Pin, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(SWITCH_2_GPIO_Port, SWITCH_2_Pin, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(SWITCH_3_GPIO_Port, SWITCH_3_Pin, GPIO_PIN_RESET);
}

void i_sens_switch_channel(channel_t channel)
{
    switch (channel)
    {
        case CH_1:
            // SWITCH_1_2 = 0, SWITCH_3 = 0
            HAL_GPIO_WritePin(SWITCH_1_GPIO_Port, SWITCH_1_Pin, GPIO_PIN_RESET);
            HAL_GPIO_WritePin(SWITCH_3_GPIO_Port, SWITCH_3_Pin, GPIO_PIN_RESET);
            break;

        case CH_2:
            // SWITCH_1_2 = 1, SWITCH_3 = 0
            HAL_GPIO_WritePin(SWITCH_1_GPIO_Port, SWITCH_1_Pin, GPIO_PIN_SET);
            HAL_GPIO_WritePin(SWITCH_3_GPIO_Port, SWITCH_3_Pin, GPIO_PIN_RESET);
            break;

        case CH_3:
            // SWITCH_1_2 = 0, SWITCH_3 = 1
            HAL_GPIO_WritePin(SWITCH_1_GPIO_Port, SWITCH_1_Pin, GPIO_PIN_RESET);
            HAL_GPIO_WritePin(SWITCH_3_GPIO_Port, SWITCH_3_Pin, GPIO_PIN_SET);
            break;

        case CH_4:
            // SWITCH_1_2 = 1, SWITCH_3 = 1
            HAL_GPIO_WritePin(SWITCH_1_GPIO_Port, SWITCH_1_Pin, GPIO_PIN_SET);
            HAL_GPIO_WritePin(SWITCH_3_GPIO_Port, SWITCH_3_Pin, GPIO_PIN_SET);
            break;

        default:
            // Fehlerbehandlung bei ungültigem Kanal
            Error_Handler();
            break;
    }
}

float calibrate_current_A(float measured_A) {
    // Platzhalter – bei Bedarf Kalibrierung einfügen
    return measured_A;
}

float i_sens_get_current_A(channel_t channel)
{
    /* 1) Sensor an & Kanal wählen */
    i_sens_activate();
    i_sens_switch_channel(channel);

    /* 2) Spannung → Rohstrom → Kalibrierter Strom */
    float v_isens  = get_voltage_isens_V();                   /* [V] */
    float raw_A    = v_isens / (INA_GAIN * SHUNT_RESISTOR);   /* [A] */
    float calibrated = calibrate_current_A(raw_A);            /* [A] */

    /* 3) In den Puffer: neue Messung an Index 0,
          alle bestehenden um 1 nach rechts schieben.
          Der letzte Wert (Index NUM_VALUES-1) fällt dabei raus. */
    if (buffer_count < NUM_VALUES) {
        // erst Pufferinhalt nach rechts schieben (nur was existiert)
        if (buffer_count > 0) {
            memmove(&current_buffer[1], &current_buffer[0],
                    (size_t)buffer_count * sizeof(float));
        }
        current_buffer[0] = calibrated;
        buffer_count++;
    } else {
        // Puffer voll: rechts schieben, letztes Element wird „gelöscht“
        memmove(&current_buffer[1], &current_buffer[0],
                (NUM_VALUES - 1) * sizeof(float));
        current_buffer[0] = calibrated;
    }

    /* 4) Median aus den aktuell vorhandenen Werten zurückgeben */
    return median_of_buffer(current_buffer, buffer_count);
}
