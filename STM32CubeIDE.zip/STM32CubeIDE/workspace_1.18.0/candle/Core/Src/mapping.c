/*
 * mapping.c
 *
 *  Created on: May 6, 2025
 *      Author: z004v3vh
 */

#include "mapping.h"
#include <math.h>  // für roundf()

// --------------------------------------------------------
// Mapping-Funktion: [0..255] -> [400..1424]
// --------------------------------------------------------

uint16_t map_value(float v, float map_in_min, float map_in_max) {
	const float outMin = (float) MAP_OUT_MIN;  // z. B. 400
	const float outMax = (float) MAP_OUT_MAX;  // z. B. 1424

	// Verhindere Division durch 0
	if (fabsf(map_in_max - map_in_min) < 1e-6f) {
		return (uint16_t) roundf(outMin);
	}

	// Normiere das Eingangssignal auf [0.0 ... 1.0]
	float relative = (v - map_in_min) / (map_in_max - map_in_min);

	// Lineare Skalierung auf PWM-Ausgabebereich
	float pwm = outMin + relative * (outMax - outMin);

	return (uint16_t) roundf(pwm);
}

#include <math.h>   // fminf, INFINITY

/**
 * Streckt einen Wert um den Mittelpunkt `center`.
 *
 * - `signal_min` / `signal_max` sind die Extremwerte des gesamten Signals.
 * - `desired_gain` ist das Wunsch-Gain.
 * - Das Gain wird automatisch so weit reduziert, dass
 *     * signal_min →   0   und
 *     * signal_max → 255
 *   nicht überschritten werden.
 *
 * Ergebnis ist identisch zu
 *     y = (value - center) * desired_gain + center;
 *     if (y < 0)   y = 0;
 *     if (y > 255) y = 255;
 * …nur ohne die Clamping-Zeilen.
 */
float stretch(float value,
                            float center,
                            float signal_min,
                            float signal_max,
                            float desired_gain)
{
    /* --- 1. maximal zulässiges Gain bestimmen -------------------- */
    float max_gain_up   = INFINITY;      /* für obere Grenze 255   */
    float max_gain_down = INFINITY;      /* für untere Grenze   0  */

    if (signal_max > center)
        max_gain_up = (255.0f - center) / (signal_max - center);

    if (signal_min < center)
        max_gain_down = (0.0f  - center) / (signal_min - center);  // >0

    /* Kleinere der beiden Limits ist das absolute Maximum           */
    float max_allowed_gain = fminf(max_gain_up, max_gain_down);

    /* Endgültiges Gain: nicht größer als erlaubt                    */
    float gain = fminf(desired_gain, max_allowed_gain);

    /* --- 2. eigentliche Transformation --------------------------- */
    float y = (value - center) * gain + center;

    /* --- 3. numerische Schutzkappe gegen Rundungsreste ----------- */
    if (y < 0.0f)   y = 0.0f;
    if (y > 255.0f) y = 255.0f;

    return y;
}
