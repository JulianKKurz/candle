/*
 * states.c
 *
 *  Created on: May 13, 2025
 *      Author: z004v3vh
 */

#include "states.h"

// ======= STATE =======
static volatile AppState current_state = STATE_INIT;

void system_state_init(void) {
    current_state = STATE_INIT;
}

AppState system_state_get(void) {
    return current_state;
}

void system_state_set(AppState state) {
    current_state = state;
}

// ======= BRIGHTNESS =======
static volatile int brightness = 0;

void brightness_set(int value) {
    if (value < BRIGHTNESS_MIN) value = BRIGHTNESS_MIN;
    if (value > BRIGHTNESS_MAX) value = BRIGHTNESS_MAX;
    brightness = value;
}

void brightness_init(void) {
	brightness_set(50);
}

int brightness_get(void) {
    return brightness;
}

void increase_brightness(void) {
	brightness_set(brightness_get() + 10);
}

void decrease_brightness(void) {
	brightness_set(brightness_get() - 10);
}

// ======= SPEED =======
static volatile int speed = 0;

void speed_init(void) {
    speed = 100;
}

int speed_get(void) {
    return speed;
}

void speed_set(int value) {
    if (value < SPEED_MIN) value = SPEED_MIN;
    if (value > SPEED_MAX) value = SPEED_MAX;
    speed = value;
}

void increase_speed(void) {
    if (speed < SPEED_MAX) {
        speed += 10;
    }
}

void decrease_speed(void) {
    if (speed > SPEED_MIN) {
        speed -= 10;
    }
}
