/*
 * system_state.c
 *
 *  Created on: May 6, 2025
 *      Author: z004v3vh
 */

#include <pwm.h>
#include "system_state.h"
#include "process_receiver.h"
#include "states.h"
#include "timer.h"
#include "well512.h"
#include "states.h"
#include "channels.h"
#include "light_programs.h"
#include "stm32f1xx_hal.h"
#include "voltage_monitoring.h"

extern ADC_HandleTypeDef hadc1;
extern TIM_HandleTypeDef htim1;
extern TIM_HandleTypeDef htim2;
extern TIM_HandleTypeDef htim3;

extern void SystemClock_Config(void);

GPIO_InitTypeDef GPIO_InitStruct = { 0 };

void system_state_loop(void) {
	switch (system_state_get()) {

	case STATE_INIT:

		HAL_GPIO_WritePin(HOLD_GPIO_Port, HOLD_Pin, GPIO_PIN_SET);

		HAL_NVIC_DisableIRQ(EXTI15_10_IRQn);

		HAL_TIM_Base_Start_IT(&htim2);
		HAL_TIM_Base_Start_IT(&htim3);

		while (__HAL_TIM_GET_COUNTER(&htim3) == 0) {
#if DEV_DEBUG == 0
			__WFI();
#endif
		}
		__HAL_TIM_SET_COUNTER(&htim3, 0);

		__HAL_TIM_SET_COUNTER(&htim1, 0);
		HAL_TIM_Base_Start(&htim1);

		timer_init();
		voltage_monitoring_init();

		init_program();

		brightness_init();
		speed_init();

		init_channels();

		candle_init();

		HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);

		system_state_set(STATE_ACTIVE);
		break;

	case STATE_ACTIVE:
		if (get_rx_state() == RX_DONE) {
			IR_Command cmd = decode_ir_code(get_last_code());

			switch (cmd) {
			case IR_CMD_ON_OFF:
				system_state_set(STATE_SLEEPING);
				break;

			case IR_CMD_MODE:
				toggle_mode();
				system_state_set(STATE_INIT);
				break;

			case IR_CMD_BRIGHTNESS_UP:
				increase_brightness();
				break;

			case IR_CMD_BRIGHTNESS_DOWN:
				decrease_brightness();
				break;

			case IR_CMD_SPEED_SLOW:
				decrease_speed();
				break;

			case IR_CMD_SPEED_RAPIDE:
				increase_speed();
				break;

			case IR_CMD_NONE:
			default:
				// Kein gültiger Befehl erkannt
				break;
			}

			// Empfänger zurücksetzen für nächsten Empfang
			reset_receiver();
		}
		break;

	case STATE_SLEEPING:
		// STOP-Modus vorbereiten
		HAL_NVIC_DisableIRQ(EXTI15_10_IRQn);
		timer_delay_ms(200);

		HAL_TIM_Base_Stop(&htim1);
		HAL_TIM_Base_Stop_IT(&htim2);
		HAL_TIM_Base_Stop_IT(&htim3);
		HAL_ADC_Stop_DMA(&hadc1);

		HAL_TIM_PWM_Stop(&htim2, TIM_CHANNEL_1);
		HAL_TIM_PWM_Stop(&htim2, TIM_CHANNEL_2);
		HAL_TIM_PWM_Stop(&htim2, TIM_CHANNEL_3);
		HAL_TIM_PWM_Stop(&htim2, TIM_CHANNEL_4);

		GPIO_InitStruct.Pin = BLUE_Pin | GREEN_Pin | RED_Pin;
		GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
		GPIO_InitStruct.Pull = GPIO_NOPULL;
		HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

		HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);

		HAL_SuspendTick();
		HAL_PWR_EnterSTOPMode(PWR_LOWPOWERREGULATOR_ON, PWR_SLEEPENTRY_WFI);

		system_state_set(STATE_ON);  // Nach Wakeup geht's weiter

		break;

	case STATE_ON:
		HAL_NVIC_DisableIRQ(EXTI15_10_IRQn);

		SystemClock_Config();
		HAL_ResumeTick();

		HAL_TIM_Base_Start_IT(&htim2);
		HAL_TIM_Base_Start_IT(&htim3);
		__HAL_TIM_SET_COUNTER(&htim1, 0);
		HAL_TIM_Base_Start(&htim1);

		GPIO_InitStruct.Pin = BLUE_Pin | GREEN_Pin | RED_Pin;
		GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
		GPIO_InitStruct.Pull = GPIO_NOPULL;
		GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
		HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

		// Nur PWM reaktivieren, keinen neuen Zufallszustand erzeugen
		HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_1);
		HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_2);
		HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_3);
		HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_4);

		system_state_set(STATE_ACTIVE);
		timer_delay_ms(200);
		HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);
		break;

	default:
		break;
	}
}
