/*
 * light_programs.c
 *  Created on: May 12 2025
 */

#include <stddef.h>
#include "light_programs.h"

/* -------------------------------------------------
 *  Externe Programmdefinitionen  (liegen in candle.c,
 *  sparkler.c, … und passen GENAU zu deiner Struktur)
 * ------------------------------------------------- */
extern const LightProgram candle;
//extern const LightProgram sparkler;

/* -------------- Tabelle aller Programme ---------- */
const LightProgram *const all_programs[] = { &candle, };
//const LightProgram *const all_programs[] = { &candle, &sparkler, };

const int num_programs = sizeof(all_programs) / sizeof(all_programs[0]);

/* ---------------- Laufzeitstatus ----------------- */
int current_program_index = 0;
const LightProgram *current_program = NULL;

/* ---------------- Implementierung ---------------- */
const LightProgram* get_program(int index) {
	return (index >= 0 && index < num_programs) ? all_programs[index] : NULL;
}

void init_program(void) {
	if (current_program == NULL) {
		// Initialisierung beim ersten Aufruf
		current_program_index = 0;
		current_program = get_program(0);
		return;
	}
}

void toggle_mode(void) {
	candle_stop();
	init_program();

	if (++current_program_index >= num_programs)
		current_program_index = 0;

	current_program = get_program(current_program_index);
	candle_run();
}

