#include "process_receiver.h"
#include "timer.h"

// Statische Variablen für den Empfang
static uint32_t tempCode = 0;
static uint8_t bitIndex = 0;
static uint32_t last_valid_code = 0;
static ReceiverState rx_state = RX_IDLE;

// Sperrtimer nach gültigem Empfang
static Timer* rx_hold_timer = NULL;

ReceiverState get_rx_state(void) {
    // Wenn DEBOUNCE aktiv, prüfen ob vorbei
    if (rx_state == RX_DEBOUNCE && rx_hold_timer) {
        if (timer_is_expired(rx_hold_timer)) {
            timer_delete(rx_hold_timer);
            rx_hold_timer = NULL;
            rx_state = RX_DONE;  // Freigabe zum Auswerten
        }
    }
    return rx_state;
}

uint32_t get_last_code(void) {
    return last_valid_code;
}

void set_last_code(uint32_t code) {
    last_valid_code = code;
}

void reset_receiver(void) {
    tempCode = 0;
    bitIndex = 0;
    last_valid_code = 0;
    rx_state = RX_IDLE;
}

// NEC-Code → Kommando übersetzen
IR_Command decode_ir_code(uint32_t code) {
    switch (code) {
        case 0x1FE48B7: return IR_CMD_ON_OFF;
        case 0x1FE7887: return IR_CMD_MODE;
        case 0x1FE20DF: return IR_CMD_BRIGHTNESS_UP;
        case 0x1FE609F: return IR_CMD_BRIGHTNESS_DOWN;
        case 0x1FE50AF: return IR_CMD_SPEED_SLOW;
        case 0x1FEF807: return IR_CMD_SPEED_RAPIDE;
        default:        return IR_CMD_NONE;
    }
}

// Haupt-Callback: wird im EXTI (PB11) aufgerufen
void ProcessReceiver_EXTI_Callback(void) {
	if (rx_state == RX_DEBOUNCE) {
	    // Warten, bis Timer abläuft. Nicht verlängern!
	    __HAL_TIM_SET_COUNTER(&htim1, 0);
	    __HAL_GPIO_EXTI_CLEAR_IT(GPIO_PIN_11);
	    return;
	}

    uint32_t counter = __HAL_TIM_GET_COUNTER(&htim1);

    if (counter > TIMEOUT_THRESHOLD) {
        tempCode = 0;
        bitIndex = 0;
        rx_state = RX_RECEIVING;
    } else if (counter > ONE_BIT_THRESHOLD) {
        tempCode |= (1UL << (31 - bitIndex));
        bitIndex++;
        rx_state = RX_RECEIVING;
    } else if (counter > ZERO_BIT_THRESHOLD) {
        tempCode &= ~(1UL << (31 - bitIndex));
        bitIndex++;
        rx_state = RX_RECEIVING;
    }

    if (bitIndex == CODE_BIT_LENGTH) {
        uint8_t cmdli = (uint8_t)(~tempCode);
        uint8_t cmd   = (uint8_t)(tempCode >> 8);

        if (cmdli == cmd) {
            last_valid_code = tempCode;
            rx_state = RX_DEBOUNCE;
            if (!rx_hold_timer) {
                rx_hold_timer = timer_create(150);
            }
        } else {
            reset_receiver();
        }

        tempCode = 0;
        bitIndex = 0;
    }

    __HAL_TIM_SET_COUNTER(&htim1, 0);
    __HAL_GPIO_EXTI_CLEAR_IT(GPIO_PIN_11);
}
