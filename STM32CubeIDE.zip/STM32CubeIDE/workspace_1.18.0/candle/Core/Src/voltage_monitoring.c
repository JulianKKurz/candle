/*
 * voltage_monitoring.c
 *
 *  Created on: Jan 25, 2025
 *      Author: z004v3vh
 */

#include "voltage_monitoring.h"
#include "main.h"

extern ADC_HandleTypeDef hadc1;
extern uint16_t adc_values[ADC_NUM_CHANNELS];  // [0]=Temp, [1]=Battery, [2]=USB_5V, [3]=ISENS

// --- Interne Zustände ---
static float battery_history[FILTER_SIZE] = {0.0f};
static uint8_t hist_index = 0;
static bool adc_initialized = false;

// --- Initialisierung ---
bool voltage_monitoring_is_initialized(void) {
    return adc_initialized;
}

bool voltage_monitoring_init(void) {
    if (hadc1.Instance == NULL || hadc1.DMA_Handle == NULL) {
        return false;
    }

    for (int i = 0; i < 5; ++i) {
        if (HAL_ADC_Start_DMA(&hadc1, (uint32_t*)adc_values, ADC_NUM_CHANNELS) == HAL_OK) {
            adc_initialized = true;
            return true;
        }
        HAL_Delay(10);
    }

    return false;
}

// --- Update & Filter ---
void voltage_monitoring_update(void) {
    if (!adc_initialized)
        return;

    float voltage = adc_values[BATTERY_ADC_INDEX] * (VREF / ADC_MAX);
    battery_history[hist_index] = voltage;
    hist_index = (hist_index + 1) % FILTER_SIZE;
}

// --- Spannungsmessungen ---
float get_voltage_battery_V(void) {
    float raw_voltage = (adc_values[BATTERY_ADC_INDEX] * VREF / ADC_MAX) * (60.0f / 33.0f);  // Spannungsteiler
    return raw_voltage;
}

float get_smoothed_battery_voltage_V(void) {
    float sum = 0.0f;
    for (int i = 0; i < FILTER_SIZE; ++i) {
        sum += battery_history[i];
    }
    return (sum / FILTER_SIZE) * (60.0f / 33.0f);  // Skalierung anwenden
}

float get_voltage_isens_V(void) {
    return adc_values[ISENS_ADC_INDEX] * VREF / ADC_MAX;
}

float get_voltage_usb_V(void) {
    return adc_values[USB_ADC_INDEX] * (VREF / ADC_MAX) * (60.0f / 33.0f);  // Annahme: gleicher Spannungsteiler
}

// --- Temperaturmessung ---
float get_temperature_mpu_C(void) {
    float vsense = adc_values[TEMP_ADC_INDEX] * (VREF / ADC_MAX);  // in Volt
    float temperature = ((1.43f - vsense) / 0.0043f) + 25.0f;       // Datenblattwerte
    return temperature;
}
