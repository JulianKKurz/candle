#include "dj_cutter.h"
#include "well512.h"
#include "crossfade.h"
#include <stdlib.h>   /* abs()   */
#include <string.h>   /* memset */
#include <math.h>

typedef struct {
    int in_point;
    int crossfade_in_end;
    int crossfade_out_begin;
    int out_point;
    int frame_counter;            /* aktueller Index innerhalb des Clips */
} Clip;

/* ------------------------------------------------------------------ */
/*          Hilfsfunktionen                                            */
/* ------------------------------------------------------------------ */

/* Erstellt einen neuen Clip, der mindestens            */
/*   2*fadeFrames + 1  lang ist und komplett in        */
/*   [0 .. totalLen-1] liegt.                          */
static Clip create_new_clip(int totalLen, int fadeFrames)
{
    Clip c;

    int min_in = 0;
    int max_in = totalLen - 2 * fadeFrames - 2;
    c.in_point = min_in + (well512_rand() % (max_in - min_in + 1));

    int min_out = c.in_point + 2 * fadeFrames + 1;
    int max_out = totalLen - 1;
    c.out_point = min_out + (well512_rand() % (max_out - min_out + 1));

    c.crossfade_in_end    = c.in_point + fadeFrames;          /* Ende Ein-Blendung   */
    c.crossfade_out_begin = c.out_point - fadeFrames;         /* Start Aus-Blendung  */
    c.frame_counter       = c.in_point;                       /* beginnt am In-Punkt */

    return c;
}

/* ------------------------------------------------------------------ */
/*          Public API                                                 */
/* ------------------------------------------------------------------ */

void dj_cutter_generate_all_channels(uint8_t **dest,
                                     const LightProgram *program)
{
    const int len         = program->length;
    const int fadeFrames  = program->fade_frames;
    const LightChannels *src = program->data;

    /* ------- Initiale Clips anlegen -------------------------------- */
    Clip cur  = create_new_clip(len, fadeFrames);
    Clip next = create_new_clip(len, fadeFrames);

    /* ------- Sequenz Frame-für-Frame schreiben --------------------- */
    for (int dstIdx = 0; dstIdx < len; ++dstIdx)
    {
        int frame = cur.frame_counter;

        /* ----------------------------------------------------------- */
        /* Bereich 1: “normaler” Clip-Teil - keine Überblendung        */
        /* ----------------------------------------------------------- */
        if (frame < cur.crossfade_out_begin)
        {
            for (int ch = 0; ch < N_CHANNELS; ++ch)
                dest[ch][dstIdx] = src->ch[ch][frame];
        }
        else
        /* ----------------------------------------------------------- */
        /* Bereich 2: Aus-Blendung + gleichzeitige Ein-Blendung        */
        /* ----------------------------------------------------------- */
        {
            int cfPos = frame - cur.crossfade_out_begin;       /* 0 … fadeFrames-1 */

            for (int ch = 0; ch < N_CHANNELS; ++ch) {
                float vOut = (float)src->ch[ch][frame];
                float vIn  = (float)src->ch[ch][next.in_point + cfPos];

                float mix = crossfade(cfPos, vOut, vIn, program->fade_frames, COSINE);
                dest[ch][dstIdx] = (uint8_t)lroundf(mix);
            }

            /* nächster Clip wird in Schritt mitgenommen               */
            next.frame_counter = next.in_point + cfPos + 1;
        }

        /* ----------------------------------------------------------- */
        /*   Frame-Counter hochzählen, ggf. Clip-Wechsel               */
        /* ----------------------------------------------------------- */
        cur.frame_counter++;

        if (cur.frame_counter > cur.out_point) {
            /* Wechsel: vorbereiteten Clip aktivieren, neuen anlegen  */
            cur  = next;
            next = create_new_clip(len, fadeFrames);
        }
    }
}
