/*
 * well512.c
 *
 *  Created on: May 11, 2025
 *      Author: z004v3vh
 */

#include "well512.h"
#include "timer.h"
#include "voltage_monitoring.h"

// Beispiel: ADC-Funktionen – musst du je nach Plattform selbst implementieren

static uint32_t state[16];
static uint32_t index = 0;

extern uint16_t adc_values[4];

static uint32_t sample_adc_entropy(void)
{
    uint32_t result = 0;
    for (int i = 0; i < 32; i += 4)
    {
    	timer_delay_ms(10);

        uint16_t t = adc_values[BATTERY_ADC_INDEX];
        uint16_t v = adc_values[TEMP_ADC_INDEX];

        uint8_t noise = ((t & 0x03) << 2) | (v & 0x03);  // 4 bit aus Rauschen
        result |= ((uint32_t)noise << i);
    }
    return result;
}

void well512_seed(uint32_t seed_array[16])
{
    for (int i = 0; i < 16; i++)
        state[i] = seed_array[i];
    index = 0;
}

void well512_seed_from_adc(void)
{
    uint32_t seed[16];
    for (int i = 0; i < 16; i++)
        seed[i] = sample_adc_entropy();
    well512_seed(seed);
}

uint32_t well512_rand(void)
{
    uint32_t a = state[index];
    uint32_t c = state[(index + 13) & 15];
    uint32_t b = a ^ c ^ (a << 16) ^ (c << 15);

    c = state[(index + 9) & 15];
    c ^= (c >> 11);

    a = state[index] = b ^ c;
    uint32_t d = a ^ ((a << 5) & 0xDA442D24U);

    index = (index + 15) & 15;
    state[index] ^= d;

    return state[index];
}
