/*
 * colors.c
 *
 *  Created on: Jan 22, 2025
 *      Author: z004v3vh
 */

#include "colors.h"

/**
 * @brief Setzt die RGB-Farbe der LED.
 * @param r Wert für Rot (0-255)
 * @param g Wert für Grün (0-255)
 * @param b Wert für Blau (0-255)
 */
void set_rgb_color(uint8_t r, uint8_t g, uint8_t b)
{
    // Setze den Compare-Wert für jeden Kanal entsprechend der RGB-Werte
    // Annahme: Timer-Periode ist 255 für 8-Bit Auflösung

    // Falls die Periode anders ist, passe die Skalierung entsprechend an
    // Beispiel: Wenn die Periode 1000 ist, dann setze Compare-Wert = (Wert * 1000) / 255

    //__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_1, r); // Rot
    //__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_2, g); // Grün
    //__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_3, b); // Blau
}
