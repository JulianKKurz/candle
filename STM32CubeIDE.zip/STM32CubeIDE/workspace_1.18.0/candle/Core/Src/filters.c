/*
 * filters.c
 *
 *  Created on: Jan 26, 2025
 *      Author: z004v3vh
 */

#include <stdbool.h>
#include "filters.h"

#ifdef __cplusplus
extern "C" {
#endif

// --------------------------------------------------------
// Hilfsfunktion: einfache IIR-Filterung
// y[n] = alpha * y[n-1] + (1 - alpha) * x[n]
// --------------------------------------------------------
float iir_filter_sample(IIRFilterConfig *cfg, float x) {
	float y = cfg->alpha * cfg->prevVal + (1.0f - cfg->alpha) * x;
	cfg->prevVal = y;
	return y;
}
