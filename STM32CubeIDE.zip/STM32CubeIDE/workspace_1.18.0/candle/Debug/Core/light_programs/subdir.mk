################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Core/light_programs/candle.c 

OBJS += \
./Core/light_programs/candle.o 

C_DEPS += \
./Core/light_programs/candle.d 


# Each subdirectory must supply rules for building sources it contributes
Core/light_programs/%.o Core/light_programs/%.su Core/light_programs/%.cyclo: ../Core/light_programs/%.c Core/light_programs/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m3 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F103xB -c -I../Core/Inc -I../Drivers/STM32F1xx_HAL_Driver/Inc/Legacy -I../Drivers/STM32F1xx_HAL_Driver/Inc -I../Drivers/CMSIS/Device/ST/STM32F1xx/Include -I../Drivers/CMSIS/Include -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"

clean: clean-Core-2f-light_programs

clean-Core-2f-light_programs:
	-$(RM) ./Core/light_programs/candle.cyclo ./Core/light_programs/candle.d ./Core/light_programs/candle.o ./Core/light_programs/candle.su

.PHONY: clean-Core-2f-light_programs

