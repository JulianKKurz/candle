Core/Src/battery_status.o: ../Core/Src/battery_status.c
