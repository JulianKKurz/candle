Core/Src/crossfade.o: ../Core/Src/crossfade.c ../Core/Inc/crossfade.h
../Core/Inc/crossfade.h:
