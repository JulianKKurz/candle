Core/Src/main.o: ../Core/Src/main.c ../Core/Inc/channels.h \
 ../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal.h \
 ../Core/Inc/stm32f1xx_hal_conf.h \
 ../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_rcc.h \
 ../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_def.h \
 ../Drivers/CMSIS/Device/ST/STM32F1xx/Include/stm32f1xx.h \
 ../Drivers/CMSIS/Device/ST/STM32F1xx/Include/stm32f103xb.h \
 ../Drivers/CMSIS/Include/core_cm3.h \
 ../Drivers/CMSIS/Include/cmsis_version.h \
 ../Drivers/CMSIS/Include/cmsis_compiler.h \
 ../Drivers/CMSIS/Include/cmsis_gcc.h \
 ../Drivers/CMSIS/Device/ST/STM32F1xx/Include/system_stm32f1xx.h \
 ../Drivers/STM32F1xx_HAL_Driver/Inc/Legacy/stm32_hal_legacy.h \
 ../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_rcc_ex.h \
 ../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_gpio.h \
 ../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_gpio_ex.h \
 ../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_exti.h \
 ../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_dma.h \
 ../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_dma_ex.h \
 ../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_cortex.h \
 ../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_adc.h \
 ../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_adc_ex.h \
 ../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_flash.h \
 ../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_flash_ex.h \
 ../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_pwr.h \
 ../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_tim.h \
 ../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_tim_ex.h \
 ../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_uart.h \
 ../Core/Inc/current_measurement.h ../Core/Inc/channels.h \
 ../Core/Inc/timer.h ../Core/Inc/states.h ../Core/Inc/main.h \
 ../Core/Inc/battery_status.h ../Core/Inc/voltage_monitoring.h \
 ../Core/Inc/process_receiver.h ../Core/Inc/main.h \
 ../Core/Inc/system_state.h ../Core/Inc/pwm.h \
 ../Core/Inc/voltage_monitoring.h
../Core/Inc/channels.h:
../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal.h:
../Core/Inc/stm32f1xx_hal_conf.h:
../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_rcc.h:
../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_def.h:
../Drivers/CMSIS/Device/ST/STM32F1xx/Include/stm32f1xx.h:
../Drivers/CMSIS/Device/ST/STM32F1xx/Include/stm32f103xb.h:
../Drivers/CMSIS/Include/core_cm3.h:
../Drivers/CMSIS/Include/cmsis_version.h:
../Drivers/CMSIS/Include/cmsis_compiler.h:
../Drivers/CMSIS/Include/cmsis_gcc.h:
../Drivers/CMSIS/Device/ST/STM32F1xx/Include/system_stm32f1xx.h:
../Drivers/STM32F1xx_HAL_Driver/Inc/Legacy/stm32_hal_legacy.h:
../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_rcc_ex.h:
../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_gpio.h:
../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_gpio_ex.h:
../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_exti.h:
../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_dma.h:
../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_dma_ex.h:
../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_cortex.h:
../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_adc.h:
../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_adc_ex.h:
../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_flash.h:
../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_flash_ex.h:
../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_pwr.h:
../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_tim.h:
../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_tim_ex.h:
../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_uart.h:
../Core/Inc/current_measurement.h:
../Core/Inc/channels.h:
../Core/Inc/timer.h:
../Core/Inc/states.h:
../Core/Inc/main.h:
../Core/Inc/battery_status.h:
../Core/Inc/voltage_monitoring.h:
../Core/Inc/process_receiver.h:
../Core/Inc/main.h:
../Core/Inc/system_state.h:
../Core/Inc/pwm.h:
../Core/Inc/voltage_monitoring.h:
