################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Core/Src/battery_status.c \
../Core/Src/channels.c \
../Core/Src/colors.c \
../Core/Src/crossfade.c \
../Core/Src/current_measurement.c \
../Core/Src/dj_cutter.c \
../Core/Src/filters.c \
../Core/Src/light_programs.c \
../Core/Src/main.c \
../Core/Src/mapping.c \
../Core/Src/process_receiver.c \
../Core/Src/pwm.c \
../Core/Src/states.c \
../Core/Src/stm32f1xx_hal_msp.c \
../Core/Src/stm32f1xx_it.c \
../Core/Src/syscalls.c \
../Core/Src/sysmem.c \
../Core/Src/system_state.c \
../Core/Src/system_stm32f1xx.c \
../Core/Src/timer.c \
../Core/Src/voltage_monitoring.c \
../Core/Src/well512.c 

OBJS += \
./Core/Src/battery_status.o \
./Core/Src/channels.o \
./Core/Src/colors.o \
./Core/Src/crossfade.o \
./Core/Src/current_measurement.o \
./Core/Src/dj_cutter.o \
./Core/Src/filters.o \
./Core/Src/light_programs.o \
./Core/Src/main.o \
./Core/Src/mapping.o \
./Core/Src/process_receiver.o \
./Core/Src/pwm.o \
./Core/Src/states.o \
./Core/Src/stm32f1xx_hal_msp.o \
./Core/Src/stm32f1xx_it.o \
./Core/Src/syscalls.o \
./Core/Src/sysmem.o \
./Core/Src/system_state.o \
./Core/Src/system_stm32f1xx.o \
./Core/Src/timer.o \
./Core/Src/voltage_monitoring.o \
./Core/Src/well512.o 

C_DEPS += \
./Core/Src/battery_status.d \
./Core/Src/channels.d \
./Core/Src/colors.d \
./Core/Src/crossfade.d \
./Core/Src/current_measurement.d \
./Core/Src/dj_cutter.d \
./Core/Src/filters.d \
./Core/Src/light_programs.d \
./Core/Src/main.d \
./Core/Src/mapping.d \
./Core/Src/process_receiver.d \
./Core/Src/pwm.d \
./Core/Src/states.d \
./Core/Src/stm32f1xx_hal_msp.d \
./Core/Src/stm32f1xx_it.d \
./Core/Src/syscalls.d \
./Core/Src/sysmem.d \
./Core/Src/system_state.d \
./Core/Src/system_stm32f1xx.d \
./Core/Src/timer.d \
./Core/Src/voltage_monitoring.d \
./Core/Src/well512.d 


# Each subdirectory must supply rules for building sources it contributes
Core/Src/%.o Core/Src/%.su Core/Src/%.cyclo: ../Core/Src/%.c Core/Src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m3 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F103xB -c -I../Core/Inc -I../Drivers/STM32F1xx_HAL_Driver/Inc/Legacy -I../Drivers/STM32F1xx_HAL_Driver/Inc -I../Drivers/CMSIS/Device/ST/STM32F1xx/Include -I../Drivers/CMSIS/Include -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"

clean: clean-Core-2f-Src

clean-Core-2f-Src:
	-$(RM) ./Core/Src/battery_status.cyclo ./Core/Src/battery_status.d ./Core/Src/battery_status.o ./Core/Src/battery_status.su ./Core/Src/channels.cyclo ./Core/Src/channels.d ./Core/Src/channels.o ./Core/Src/channels.su ./Core/Src/colors.cyclo ./Core/Src/colors.d ./Core/Src/colors.o ./Core/Src/colors.su ./Core/Src/crossfade.cyclo ./Core/Src/crossfade.d ./Core/Src/crossfade.o ./Core/Src/crossfade.su ./Core/Src/current_measurement.cyclo ./Core/Src/current_measurement.d ./Core/Src/current_measurement.o ./Core/Src/current_measurement.su ./Core/Src/dj_cutter.cyclo ./Core/Src/dj_cutter.d ./Core/Src/dj_cutter.o ./Core/Src/dj_cutter.su ./Core/Src/filters.cyclo ./Core/Src/filters.d ./Core/Src/filters.o ./Core/Src/filters.su ./Core/Src/light_programs.cyclo ./Core/Src/light_programs.d ./Core/Src/light_programs.o ./Core/Src/light_programs.su ./Core/Src/main.cyclo ./Core/Src/main.d ./Core/Src/main.o ./Core/Src/main.su ./Core/Src/mapping.cyclo ./Core/Src/mapping.d ./Core/Src/mapping.o ./Core/Src/mapping.su ./Core/Src/process_receiver.cyclo ./Core/Src/process_receiver.d ./Core/Src/process_receiver.o ./Core/Src/process_receiver.su ./Core/Src/pwm.cyclo ./Core/Src/pwm.d ./Core/Src/pwm.o ./Core/Src/pwm.su ./Core/Src/states.cyclo ./Core/Src/states.d ./Core/Src/states.o ./Core/Src/states.su ./Core/Src/stm32f1xx_hal_msp.cyclo ./Core/Src/stm32f1xx_hal_msp.d ./Core/Src/stm32f1xx_hal_msp.o ./Core/Src/stm32f1xx_hal_msp.su ./Core/Src/stm32f1xx_it.cyclo ./Core/Src/stm32f1xx_it.d ./Core/Src/stm32f1xx_it.o ./Core/Src/stm32f1xx_it.su ./Core/Src/syscalls.cyclo ./Core/Src/syscalls.d ./Core/Src/syscalls.o ./Core/Src/syscalls.su ./Core/Src/sysmem.cyclo ./Core/Src/sysmem.d ./Core/Src/sysmem.o ./Core/Src/sysmem.su ./Core/Src/system_state.cyclo ./Core/Src/system_state.d ./Core/Src/system_state.o ./Core/Src/system_state.su ./Core/Src/system_stm32f1xx.cyclo ./Core/Src/system_stm32f1xx.d ./Core/Src/system_stm32f1xx.o ./Core/Src/system_stm32f1xx.su ./Core/Src/timer.cyclo ./Core/Src/timer.d ./Core/Src/timer.o ./Core/Src/timer.su ./Core/Src/voltage_monitoring.cyclo ./Core/Src/voltage_monitoring.d ./Core/Src/voltage_monitoring.o ./Core/Src/voltage_monitoring.su ./Core/Src/well512.cyclo ./Core/Src/well512.d ./Core/Src/well512.o ./Core/Src/well512.su

.PHONY: clean-Core-2f-Src

